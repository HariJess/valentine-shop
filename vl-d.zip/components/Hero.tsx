"use client";

import React from 'react';
import { useScrollCarousel } from './ScrollCarousel';

const Hero: React.FC = () => {
  const { currentSection, scrollProgress } = useScrollCarousel();
  const isActive = currentSection === 0;
  const sectionProgress = scrollProgress * 4; // 4 = totalSections - 1
  const parallaxOffset = sectionProgress * 50;

  return (
    <section className="min-h-screen bg-gray-100 relative overflow-hidden flex items-center justify-centers">
      {/* Parallax Background Elements */}
      <div 
        className="absolute inset-0 transition-transform duration-700"
        style={{ transform: `translateY(${parallaxOffset}px)` }}
      >
        <div className="absolute top-32 left-20 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-32 right-20 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl animate-pulse" />
      </div>

      <div className="container mx-auto px-4 sm:px-6 relative z-10">
        <div className="max-w-7xl mx-auto">
          {/* Main Dashboard Layout */}
          <div className={`grid lg:grid-cols-12 gap-6 transition-all duration-1000 ${
            isActive ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'
          }`}>
            {/* Left Column - Stats & Info */}
            <div className="lg:col-span-3 space-y-4 sm:space-y-6">
              {/* Nutrition Widget */}
              <div className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-sm hover:shadow-lg transition-all duration-300 transform hover:scale-105">
                <div className="flex items-center space-x-4 mb-6">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-orange-500 rounded-xl sm:rounded-2xl flex items-center justify-center">
                    <div className="w-3 h-6 bg-white rounded-full"></div>
                  </div>
                  <div>
                    <div className="text-gray-400 text-xs sm:text-sm">36°</div>
                    <div className="text-gray-600 font-medium text-sm sm:text-base">Nutr</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-4 sm:mb-6">
                  <div className="bg-gray-900 rounded-xl sm:rounded-2xl p-3 sm:p-4 h-12 sm:h-16"></div>
                  <div className="bg-purple-600 rounded-xl sm:rounded-2xl p-3 sm:p-4 h-12 sm:h-16 flex items-center justify-center">
                    <span className="text-white font-bold text-sm sm:text-base">65°</span>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="text-xl sm:text-2xl font-bold text-gray-900">2,227</div>
                  <div className="space-y-2 text-xs sm:text-sm text-gray-600">
                    <div className="flex justify-between">
                      <span>Grain</span>
                      <span>~</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Carbs</span>
                      <span>~</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Sugar</span>
                      <span>~</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Center Column - Profile */}
            <div className="lg:col-span-6 flex items-center justify-center">
              <div className="relative">
                <div className="w-64 h-64 sm:w-80 sm:h-80 bg-gray-900 rounded-full flex items-center justify-center overflow-hidden transform hover:scale-105 transition-transform duration-500">
                  <img
                    src="https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400&h=600&fit=crop"
                    alt="Josh - Portfolio"
                    className="w-52 h-64 sm:w-64 sm:h-80 object-cover object-center"
                  />
                </div>
                
                {/* Floating Chat Bubble */}
                <div className="absolute bottom-6 sm:bottom-8 left-1/2 transform -translate-x-1/2 bg-white rounded-xl sm:rounded-2xl px-4 sm:px-6 py-2 sm:py-3 shadow-lg animate-bounce">
                  <div className="flex space-x-2">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - Goals & Stats */}
            <div className="lg:col-span-3 space-y-4 sm:space-y-6">
              {/* Goal Widget */}
              <div className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-sm hover:shadow-lg transition-all duration-300 transform hover:scale-105">
                <div className="text-4xl sm:text-6xl font-bold text-gray-900 mb-2">97</div>
                <div className="text-lg sm:text-xl font-bold text-gray-900 mb-1">Goal</div>
                <div className="text-lg sm:text-xl font-bold text-gray-900 mb-4">Reco</div>
                <div className="text-gray-500 text-xs sm:text-sm">$ 16700</div>
              </div>

              {/* Heart Rate Widget */}
              <div className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-sm hover:shadow-lg transition-all duration-300 transform hover:scale-105">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gray-100 rounded-xl sm:rounded-2xl flex items-center justify-center mb-4">
                  <div className="w-6 h-6 text-red-500">❤️</div>
                </div>
                <div className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">44'</div>
                <div className="text-gray-600 text-sm sm:text-base">Standard</div>
                <div className="text-gray-600 text-sm sm:text-base">Snooze</div>
              </div>

              {/* Progress Widget */}
              <div className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-sm hover:shadow-lg transition-all duration-300 transform hover:scale-105">
                <div className="text-gray-500 text-xs sm:text-sm mb-2">H2O</div>
                <div className="relative w-16 h-16 sm:w-20 sm:h-20 mb-4">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                    <path
                      className="text-gray-200"
                      stroke="currentColor"
                      strokeWidth="3"
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                    <path
                      className="text-blue-600"
                      stroke="currentColor"
                      strokeWidth="3"
                      strokeLinecap="round"
                      fill="none"
                      strokeDasharray="22, 100"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-xl sm:text-2xl font-bold text-gray-900">22</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Hello Josh Section */}
          <div className="mt-12 sm:mt-16 text-center">
           <h1 className={`text-3xl sm:text-4xl md:text-6xl font-bold text-gray-900 mb-4 transition-all duration-1000 delay-300 ${
             isActive ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'
           }`}>
              Hello, Josh
            </h1>
           <p className={`text-gray-500 text-base sm:text-lg transition-all duration-1000 delay-500 ${
             isActive ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'
           }`}>🕐 18 minutes ago</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
